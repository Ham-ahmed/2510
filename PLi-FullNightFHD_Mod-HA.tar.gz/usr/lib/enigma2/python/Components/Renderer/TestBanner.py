from Components.Renderer.Renderer import Renderer
from enigma import ePixmap

class TestBanner(Renderer):
    GUI_WIDGET = ePixmap
    def __init__(self):
        Renderer.__init__(self)
        try:
            with open("/tmp/test_banner.log", "w") as f:
                f.write("TestBanner Loaded OK\n")
        except:
            pass
